# Uml editor
## Y'all wanna try to come up with a name for this program?

### Implemented:
* Class Blocks
* A rough model to store block data
* A model to display blocks
* Drag and drop (Mostly)
* Blocks can be edited/deleted

### Started
* Save/load functionality
* Links

### To Be Implemented
* Keep class blocks bound to the window when dragging
* Make links deletable
* Factories for dialogs and classes/links
